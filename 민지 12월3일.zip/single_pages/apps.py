from django.apps import AppConfig


class SinglePagesConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'single_pages'

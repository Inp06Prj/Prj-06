from django.contrib import admin
from .models import Pro_User, Calendar

admin.site.register(Pro_User)

admin.site.register(Calendar)